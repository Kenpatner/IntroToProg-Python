#one assignment, two instructions, one script.
#data
#objFile = an object that represents a file
#objFiledata = variable that the pickle loaded its contents into.

import pickle
#must import the pickle module in order for pickle to work. The first 3 lines ask the user
#for some NBA player information and it's stored in a list format for pickle database. 
try:
    player = str(input("Enter an NBA player name"))
    jerseynumber = int(input ("Enter his jersey number"))
    NBADatabase = [player, jerseynumber]
    #open the players.dat file,write the data above with the pickle.dump() method, then close the file
    objFile = open("/Users/kenpatner/Documents/_pythonclass/Assignment07/players.dat", "wb")
    pickle.dump(NBADatabase, objFile)
    objFile.close()
    #reopen the players.dat file, read it back with the pickle.load() method this time, close it after.  Then print what's within. 
    objFile = open("/Users/kenpatner/Documents/_pythonclass/Assignment07/players.dat", "rb")
    objFiledata = pickle.load(objFile)
    objFile.close()
    print (objFiledata)
except ZeroDivisionError as e:
    print("Python says no way because", e)
except ValueError as e:
    print ("I asked for a Player's JERSEY NUMBER, not his name")

#The Exception Handling is included within.  The user is required to input the player variable as a string, and the jerseynumber as
    #an integer.  Say the user inputs a string instead of an integer at "jerseynumber," I first ask, just as a test, to throw the 
    #"ZeroDivisionError" error (but knowing it won't throw that, it's completely not applicable), but secondarily to throw the "ValueError"
    # out as the ValueError is the applicable error for example when an integer is inputted but expects a string. It predictably skips over
    #the ZeroDivisionError and straight to the 2nd error handler. 
