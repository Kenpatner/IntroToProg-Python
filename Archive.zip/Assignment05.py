#open and write into a new txt file called todo.txt with w+
objFile = open("/Users/kenpatner/Documents/_pythonclass/Assignment05/todo.txt", "w+")
#write in these items for the dictionary, stored in the dicRow variable:
dicRow = {"Clean House":"low","Pay Bills":"high"}
lstRow = []
lstRow.append(dicRow)
#write the above info stored in dicRow into the todo.txt file
objFile.write(str(dicRow))
#test what this variable prints
for x in dicRow:
    print (x,",",dicRow[x])
#don't forget to close the txt file after opening and writing into it:
objFile.close()


choice = None
while choice != "5":
    print(
    """
    Menu
    Press 1 show current data
    Press 2 to add a new item
    Press 3 to remove an existing item
    Press 4 to save data to file
    Press 5 to quit
    """
    )
    choice = input ("please pick a choice\n")
    print ()
    if choice == "5":
        print ("Thanks for stopping by")
    elif choice == "1":
        for x in dicRow:
            print(x, ",", dicRow[x])
    elif choice == "2":
        # THIS NUMBER 2 IS HOW YOU add a new item (or a key and a value pair) to a dictionary.
        # the item is the key, the priority is the value.
        item = input ("Which task would you like to add?")
        if item not in dicRow:
            priority = input ("what level priority is it?")
            dicRow[item] = priority
        else:
            print ("that task is already on the list")
    elif choice == "3":
        item = input ("Which item would you like to delete?")
        if item in dicRow:
            del dicRow[item]
            print ("Ok, deleted")
        else:
            print ("that item is not on the list")
    elif choice == "4":
        save = input ("Would you like to save your information? y/n")
        if save == "y":
            # Open the text file (.txt) called "HomeInventory" and save the above data into it by "w'riting into it.
            objFile = open("/Users/kenpatner/Documents/_pythonclass/Assignment05/todo.txt", "w")
            # below we're making the information in the "tuptotal" into strings and writing it in.
            objFile.write(str(dicRow))
            # once inputted, close the txt file to save it.
            objFile.close()
            print("Done, and thank you!")
        # if the user doesn't put "y", they can really put anything else, and the below information will run without having saved the info.
        else:
            print("That's cool, nothing written down but thanks for your input anyway")
#
