# Title: Working with Dictionaries
# Dev:   Ken Patner
# Date:  August 9, 2019
# ChangeLog:
#  Ken Patner, 08/09/2019, Created starting template
#  Added code to complete assignment 5

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strChoice = Capture the user option selection

#open and write into a new txt file called todo.txt with "w+"
objFile = open("/Users/kenpatner/Documents/_pythonclass/Assignment05/todo.txt", "w+")
#write in these items for the dictionary, stored in the dicRow variable:
dicRow = {"Clean House":"low","Pay Bills":"high"}
lstRow = []
lstRow.append(dicRow)
#write the above info stored in dicRow into the todo.txt file
objFile.write(str(dicRow))
#test what this variable prints
for x in dicRow:
    print (x,",",dicRow[x])
#don't forget to close the txt file for now after opening and writing into it:
objFile.close()

#now to run through the menu and its options.  We start with the user's choice being nothing.  As long as the option chose
#is NOT 5 (which would make the while loop "false" (because 5 not equaling 5 is false) and would break out of the loop. Otherwise
#the menu will forever continue to loop.
strChoice = None
while strChoice != "5":
    print(
    """
    Menu
    Press 1 show current data
    Press 2 to add a new item
    Press 3 to remove an existing item
    Press 4 to save data to file
    Press 5 to quit
    """
    )
    strChoice = input ("please pick a choice\n")
    print ()
    #if the choice is 5, it exits.
    if strChoice == "5":
        print ("Thanks for stopping by")
    #if "1" is selected, the below is run where a variable x is placed for every line in the dictionary and we print the key and the value for x.
    elif strChoice == "1":
        for x in dicRow:
            print(x, ",", dicRow[x])
    # if "2" is selected, a new item is added (or a key and a value pair) to a dictionary.
    # the item is the key, the priority is the value.
    elif strChoice == "2":
        item = input ("Which task would you like to add?")
        if item not in dicRow:
            priority = input ("what level priority is it?")
            dicRow[item] = priority
        else:
            print ("that task is already on the list")
    #selecting "3" will delete a task as long as it's in the dictionary.
    elif strChoice == "3":
        item = input ("Which item would you like to delete?")
        if item in dicRow:
            del dicRow[item]
            print ("Ok, deleted")
        else:
            print ("that item is not on the list")
    #Finally, "4" asks if the information is to be saved, if "y" is entered, read on...
    elif strChoice == "4":
        save = input ("Would you like to save your information? y/n")
        if save == "y":
            # Open the text file (.txt) called "todo.txt" and save the above data into it by "w'riting into it.
            objFile = open("/Users/kenpatner/Documents/_pythonclass/Assignment05/todo.txt", "w")
            # below we're making the information in the "dicRow" into strings and writing it in.
            objFile.write(str(dicRow))
            # once inputted, close the txt file to save it.
            objFile.close()
            print("Done, and thank you!")
        # if the user doesn't put "y", they can really put anything else, and the below information will run without having saved the info.
        else:
            print("That's cool, nothing written down but thanks for your input anyway")

